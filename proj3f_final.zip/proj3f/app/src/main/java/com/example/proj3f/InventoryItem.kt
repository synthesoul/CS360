package com.example.proj3f

data class InventoryItem(
    val id: Int,
    val name: String,
    val quantity: Int,
    val description: String
)
