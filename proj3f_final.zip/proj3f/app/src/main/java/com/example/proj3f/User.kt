package com.example.proj3f

data class User(
    val id: Int,
    val username: String,
    val password: String
)
